//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by SimpleWin.rc
//
#define IDC_MYICON                      2
#define IDD_SIMPLEWIN_DIALOG            102
#define IDD_ABOUTBOX                    103
#define IDS_APP_TITLE                   103
#define IDM_ABOUT                       104
#define IDM_EXIT                        105
#define IDS_HELLO                       106
#define IDI_SIMPLEWIN                   107
#define IDI_SMALL                       108
#define IDC_SIMPLEWIN                   109
#define IDR_MAINFRAME                   128
#define FID_HAND                        129
#define FID_BUTTON                      130
#define IDR_TEXT                        131
#define IDR_MOVIE                       132
#define IDC_VERSION                     1000
#define IDM_OPEN                        32771
#define IDM_CLOSE                       32772
#define IDM_100                         32773
#define IDM_VIEWALL                     32774
#define IDM_ZOOMIN                      32775
#define IDM_ZOOMOUT                     32776
#define IDM_FULLSCREEN                  32777
#define IDM_HIGHQ                       32778
#define IDM_PLAY                        32779
#define IDM_REWIND                      32780
#define IDM_FORWARD                     32781
#define IDM_BACK                        32782
#define IDM_LOOP                        32783
#define IDM_SELECTALL                   32785
#define IDM_CUT                         32786
#define IDM_COPY                        32787
#define IDM_PASTE                       32788
#define IDM_CLEAR                       32789
#define IDM_UNDO                        32790
#define IDM_ZOOMIN_CONTEXT              32791
#define ID_X_COULDNOTLOADIMAGE          32792
#define IDC_STATIC                      -1

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        131
#define _APS_NEXT_COMMAND_VALUE         32789
#define _APS_NEXT_CONTROL_VALUE         1001
#define _APS_NEXT_SYMED_VALUE           110
#endif
#endif
