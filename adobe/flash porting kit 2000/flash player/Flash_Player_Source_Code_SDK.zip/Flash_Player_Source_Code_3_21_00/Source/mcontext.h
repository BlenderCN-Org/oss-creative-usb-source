/****************************************************************************
CONFIDENTIAL AND PROPRIETARY INFORMATION.  The entire contents of this file
is Copyright � Macromedia, Inc. 1993-1998, All Rights Reserved.  This
document is an unpublished trade secret of Macromedia, Inc. and may not be
viewed, copied or distributed by anyone, without the specific, written
permission of Macromedia, Inc. 
****************************************************************************/

#define mContext		150
	#define icZoomIn		1
	#define icZoomOut		2	
	#define icShowAll		3

	#define icHighQuality	5

	#define icPlay			7	
	#define icLoop			8
		
	#define icRewind		10
	#define icForward		11	
	#define icBack			12	
	#define icAbout			13	
